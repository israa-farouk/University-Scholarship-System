    <!-- header-start -->
    <header>
        <div class="header-area ">
            <div id="sticky-header" class="main-header-area">
                <div class="container-fluid ">
                    <div class="header_bottom_border">
                        <div class="row align-items-center">
                            <div class="col-xl-3 col-lg-2">
                                <div class="logo">
                                    <a href="<?php echo BASE_URL . '/index.php'; ?>">
                                        <img src="../../assets/images/logo.png" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-7">
                                <div class="main-menu  d-none d-lg-block">
                                    <nav>
                                        <ul id="navigation">
                                            <li><a href="<?php echo BASE_URL . '/admin/scholarships/index.php'; ?>">Manage Scholarships</a></li>
                                            <li><a href="<?php echo BASE_URL . '/admin/users/index.php'; ?>">Award Applicants</a></li>
                                            <li><a href="<?php echo BASE_URL . '/admin/type/index.php'; ?>">Manage Type</a></li>
                                            <li><a href="<?php echo BASE_URL . '/admin/dashboard.php'; ?>">My Account</a></li>
                                        </ul>
                                        
                                    </nav>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 d-none d-lg-block">
                                <div class="Appointment">
                                    <div class="phone_num d-none d-xl-block">
                                        <a href="#">Log in</a>
                                    </div>
                                    <div class="d-none d-lg-block">
                                        <a class="boxed-btn3" href="#">Post a Job</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="mobile_menu d-block d-lg-none"></div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </header>
    <!-- header-end -->