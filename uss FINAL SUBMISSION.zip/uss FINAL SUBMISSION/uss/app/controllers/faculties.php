<?php

include(ROOT_PATH . "/app/database/db.php");

$table = 'faculties';

$id = '';
$name = '';

$faculties = selectAll($table);

if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $faculty = selectOne($table, ['id' => $id]);
    $id = $faculty['id'];
    $name = $faculty['name'];
    $description = $faculty['description'];
}

