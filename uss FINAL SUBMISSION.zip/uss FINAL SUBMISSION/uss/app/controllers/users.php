<?php

include(ROOT_PATH . "/app/database/db.php");
include(ROOT_PATH . "/app/helpers/validateUser.php");


$errors = array();
$username = '';
$email = '';
$password = '';
$passwordConf = '';
$table = 'users';

if (isset($_POST['login-btn'])){
    $errors = validateLogin($_POST);

    if (count($errors) === 0){
        $user = selectOne($table, ['username' => $_POST['username']]);
        if ($user && ($_POST['password'] == $user['password'])) {

            //login, redirect
            $_SESSION['id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['admin'] = $user['admin'];
            $_SESSION['student'] = $user['student'];
            $_SESSION['professor'] = $user['professor'];
            $_SESSION['message'] = 'You are now logged in';
            $_SESSION['type'] = 'success';

            if($_SESSION['admin']){
                header('location: ' . BASE_URL . '/admin/scholarships/index.php');
    
            } else if($_SESSION['student']){
                header('location: ' . BASE_URL . '/Student.php');
    
            } else if($_SESSION['professor']){
                header('location: ' . BASE_URL . '/Professor.php');
            }
            exit();
            
        } else{
            array_push($errors, 'Wrong credentials');

        }
    }
}

