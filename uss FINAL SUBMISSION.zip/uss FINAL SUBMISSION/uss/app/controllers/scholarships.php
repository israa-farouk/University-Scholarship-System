<?php

include(ROOT_PATH . "/app/database/db.php");

$table = 'scholarships';

$type = selectAll('type');
$faculties = selectAll('faculties');
$scholarships = selectAll($table);

$id = "";
$title = "";
$body = "";
$oneType_id = "";
$faculty_id = "";
$citizenship = "";
$award_value = "";
$gpa = "";
$year_entering = "";
$deadline = "";
$published = "";

if(isset($_GET['id'])) {
    $scholarship = selectOne($table, ['id' => $_GET['id']]);
   
    $id = $scholarship['id'];
    $title = $scholarship['title'];
    $body = $scholarship['body'];
    $oneType_id = $scholarship['oneType_id'];
    $faculty_id = $scholarship['faculty_id'];
    $citizenship = $scholarship['citizenship'];
    $award_value = $scholarship['award_value'];
    $gpa = $scholarship['gpa'];
    $year_entering = $scholarship['year_entering'];
    $deadline = $scholarship['deadline'];
    $published = $scholarship['published'];
}

if(isset($_GET['delete_id'])) {
    $count = delete($table, $_GET['delete_id']);
    header("location: " . BASE_URL . "/admin/scholarships/index.php");
    exit();
}

if(isset($_GET['published']) && isset($_GET['p_id'])) {
    $published = $_GET['published'];
    $p_id = $_GET['p_id'];
    /// .. update published
    $count = update($table, $p_id, ['published' => $published]);
    header("location: " . BASE_URL . "/admin/scholarships/index.php");
    exit();
}

if(isset($_POST['add-scholarship'])){
    //dd($_POST);
    unset($_POST['add-scholarship']);
    $_POST['user_id'] = 1;
    $_POST['published'] = isset($_POST['published']) ? 1 : 0;

    $post_id = create($table, $_POST);
    header("location: " . BASE_URL . "/admin/scholarships/index.php");
    exit();
    
}

if(isset($_POST['update-scholarship'])){
    $id = $_POST['id'];
    unset($_POST['update-scholarship'], $_POST['id']);
    $_POST['user_id'] = 1;
    $_POST['published'] = isset($_POST['published']) ? 1 : 0;

    $post_id = update($table, $id, $_POST);
    header("location: " . BASE_URL . "/admin/scholarships/index.php");
    exit();

}