<?php

include(ROOT_PATH . "/app/database/db.php");

$table = 'type';

$id = '';
$name = '';
$description = '';

$type = selectAll($table);

if (isset($_POST['add-type'])) {
    unset($_POST['add-type']);
    $oneType_id = create($table, $_POST);
    $_SESSION['message'] = 'Type created successfully';
    $_SESSION['type'] = 'success';
    header('location: ' . BASE_URL . '/admin/type/index.php');
    exit();
}

if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $oneType = selectOne($table, ['id' => $id]);
    $id = $oneType['id'];
    $name = $oneType['name'];
    $description = $oneType['description'];
}

if (isset($_GET['del_id'])){
    $id = $_GET['del_id'];
    $count = delete($table, $id);
    $_SESSION['message'] = 'Type deleted successfully';
    $_SESSION['type'] = 'success';
    header('location: ' . BASE_URL . '/admin/type/index.php');
    exit();
}

if (isset($_POST['update-oneType'])){
    $id = $_POST['id'];
    unset($_POST['update-oneType'], $_POST['id']);
    $oneType_id = update($table, $id, $_POST);
    $_SESSION['message'] = 'Type updated successfully';
    $_SESSION['type'] = 'success';
    header('location: ' . BASE_URL . '/admin/type/index.php');
    exit();
}