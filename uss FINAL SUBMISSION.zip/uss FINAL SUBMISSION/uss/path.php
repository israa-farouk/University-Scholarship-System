<?php
define('ROOT_PATH', realpath(dirname(__FILE__)));
define('BASE_URL', "http://127.0.0.1/uss");
