<?php include("path.php");
//include(ROOT_PATH . "/app/database/db.php") ;
?>
<?php include(ROOT_PATH . "/app/controllers/users.php"); ?>

<?php

$scholarships = array();
$scholarshipsTitle = 'Search by Keyword';

if(isset($_POST['search-term'])){
    $scholarshipsTitle = "You searched for '" . $_POST['search-term'] . "'";
    $scholarships = searchScholarships($_POST['search-term']);


}
else {
    $scholarships = getPublishedScholarships();
}
?>

<?php  $scholarships1 = getPublishedScholarships();



?>

<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        .dropbtn {
            background-color: #3498DB;
            color: white;
            padding: 16px;
            font-size: 16px;
            border: none;
            cursor: pointer;
        }

            .dropbtn:hover, .dropbtn:focus {
                background-color: #2980B9;
            }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            overflow: auto;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }

            .dropdown-content a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

        .dropdown a:hover {
            background-color: #ddd;
        }

        .show {
            display: block;
        }
    </style>
    <style>
        .dropbtn {
            background-color: #3498DB;
            color: white;
            padding: 16px;
            font-size: 16px;
            border: none;
            cursor: pointer;
        }

            .dropbtn:hover, .dropbtn:focus {
                background-color: #2980B9;
            }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content1 {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            overflow: auto;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }

            .dropdown-content1 a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

        .dropdown a:hover {
            background-color: #ddd;
        }

        .show {
            display: block;
        }
    </style>
    <style>
        .dropbtn {
            background-color: #3498DB;
            color: white;
            padding: 16px;
            font-size: 16px;
            border: none;
            cursor: pointer;
        }

            .dropbtn:hover, .dropbtn:focus {
                background-color: #2980B9;
            }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content2 {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            overflow: auto;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }

            .dropdown-content2 a {
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
            }

        .dropdown a:hover {
            background-color: #ddd;
        }

        .show {
            display: block;
        }
    </style>
    <style>
        * {
            margin: 0px;
            padding: 0px;
            font-family: Helvetica, Arial, sans-serif;
        }

        /* Full-width input fields */
        input[type=text], input[type=password] {
            width: 90%;
            padding: 12px 20px;
            margin: 8px 26px;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
            font-size: 16px;
        }

        /* Full-width body input fields */
        input[type=bodytext] {
            width: 90%;
            padding: 12px 20px;
            margin: 0px 0px;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
            font-size: 16px;
        }
        /* Set a style for all buttons */
        button {
            background-color: #4CAF50;
            color: white;
            padding: 14px 20px;
            margin: 8px 26px;
            border: none;
            cursor: pointer;
            width: 90%;
            font-size: 20px;
        }

            button:hover {
                opacity: 0.8;
            }

        /* Center the image and position the close button */
        .imgcontainer {
            text-align: center;
            margin: 24px 0 12px 0;
            position: relative;
        }

        .avatar {
            width: 200px;
            height: 200px;
            border-radius: 50%;
        }

        /* The Modal (background) */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }

        /* Modal Content Box */
        .modal-content {
            background-color: #fefefe;
            margin: 4% auto 15% auto;
            border: 1px solid #888;
            width: 40%;
            padding-bottom: 30px;
        }

        /* The Close Button (x) */
        .close {
            position: absolute;
            right: 25px;
            top: 0;
            color: #000;
            font-size: 35px;
            font-weight: bold;
        }

            .close:hover, .close:focus {
                color: red;
                cursor: pointer;
            }

        /* Add Zoom Animation */
        .animate {
            animation: zoom 0.6s
        }

        @keyframes zoom {
            from {
                transform: scale(0)
            }

            to {
                transform: scale(1)
            }
        }
    </style>

    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Homepage</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- <link rel="manifest" href="site.webmanifest"> -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/icons8-scholarship-32.png">
    <!-- Place favicon.ico in the root directory -->
    <!-- CSS here -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <link rel="stylesheet" href="assets/css/flaticon.css">
    <link rel="stylesheet" href="assets/css/gijgo.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <!-- <link rel="stylesheet" href="css/responsive.css"> -->
</head>

<body>
    <!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->
    <!-- header-start -->
    <header>
        <div class="header-area ">
            <div id="sticky-header" class="main-header-area sticky">
                <div class="container-fluid ">
                    <div class="header_bottom_border">
                        <div class="row align-items-center">
                            <div class="col-xl-3 col-lg-2">
                                <div class="logo">
                                    <a href="<?php echo BASE_URL . '/index.php' ?>">
                                        <img src="../logo/logo.png" alt="">
                                    </a>
                                </div>
                            </div>
                            <div class="col-xl-6 col-lg-700">
                                <div class="main-menu  d-none d-lg-block">
                                    <nav>
                                        <ul id="navigation">
                                            <li><a href="<?php echo BASE_URL . '/index.php' ?>">Home</a></li>
                                            <li><a href="#schlist">Browse Scholarships</a></li>
                                            <li><a onclick="document.getElementById('modal-wrapper').style.display='block'">My Account</a></li>
                                            <li><a href="<?php echo BASE_URL . '/Contact.php' ?>">Contact Us</a></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 d-none d-lg-block">
                                <div class="Appointment">
                                    <div class="d-none d-lg-block">
                                        <a class="boxed-btn3" onclick="document.getElementById('modal-wrapper').style.display='block'" style="width:200px; margin-top:0px; margin-left:160px;">
                                            Log in
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="mobile_menu d-block d-lg-none">
                                    <div class="slicknav_menu">
                                        <a href="#" aria-haspopup="true" role="button" tabindex="0" class="slicknav_btn slicknav_collapsed" style="outline: none;"><span class="slicknav_menutxt">MENU</span><span class="slicknav_icon"><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span></span></a><ul class="slicknav_nav slicknav_hidden" aria-hidden="true" role="menu" style="display: none;">
                                            <li><a href="<?php echo BASE_URL . '/index.php' ?>" role="menuitem" tabindex="-1">home</a></li>
                                            <li><a href="#schlist" role="menuitem" tabindex="-1">Browse Scholarships</a></li>
                                            <li><a onclick="document.getElementById('modal-wrapper').style.display='block'" role="menuitem" tabindex="-1">My Account</a></li>
                                            <li><a href="<?php echo BASE_URL . '/Contact.php' ?>" role="menuitem" tabindex="-1">Contact Us</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </header>
    <!-- header-end -->

    <div id="modal-wrapper" class="modal">

        <form class="modal-content animate" action="index.php" method="post">

            <div class="imgcontainer">
                <span onclick="document.getElementById('modal-wrapper').style.display='none'" class="close" title="Close">×</span>
                <img src="assets/images/2.png" alt="Avatar" class="avatar">
                <h1 style="text-align:center">Log in</h1>
            </div>

            <div class="container">
                <input type="text" name="username" class="text-input" placeholder="Username" required="">
                <input type="password" name="password" class="text-input" placeholder="Password" required="">
                <button type="submit" name="login-btn" class="btn">Login</button>
            </div>
        </form>
    </div>

    <script type="text/javascript">
        // If user clicks anywhere outside of the modal, Modal will close

        var modal = document.getElementById('modal-wrapper');
        window.onclick = function (event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>

    <!-- slider_area_start -->
    <div class="slider_area">
        <div class="single_slider  d-flex align-items-center slider_bg_1">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-7 col-md-6">
                        <div class="slider_text">
                            <h5 class="wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".2s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.2s; animation-name: fadeInLeft;">1000+ Scholarships Available</h5>
                            <h3 class="wow fadeInLeft" data-wow-duration="1s" data-wow-delay=".3s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.3s; animation-name: fadeInLeft;">Scholarships for you</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="ilstration_img wow fadeInRight d-none d-lg-block text-right" data-wow-duration="1s" data-wow-delay=".2s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.2s; animation-name: fadeInRight;">
            <img src="assets/images/banner/illustration.png" alt="">
        </div>
    </div>
    <!-- slider_area_end -->
    <!-- catagory_area -->
    <div class="catagory_area">
        <div class="container">
            

        <div class="job_listing_area">

        <div class="container">
                <div class="col-lg-6">
                    <br>
                    <div class="section_title">
                        <a id="schlist"><h3>Search for Scholarships</h3></a>
                    </div>
                </div>
            <!-- Search -->
        <div class="search-div">
          <form action="index.php" method="post">
            <input type="text" name="search-term" class="text-input" placeholder="Search...">
          </form>
        </div>
        <!-- // Search -->
        <br>

            <div class="row align-items-center">
                
                <div class="col-lg-6">
                    
                    <div class="section_title">
                        <a id="schlist"><h3><?php echo $scholarshipsTitle ?></h3></a>
                    </div>
                </div>
                
            </div>
            <div class="job_lists">
                <div class="row">
                    

                <?php foreach ($scholarships as $scholarship): ?>
                    <div class="col-lg-12 col-md-12">
                        <div class="single_jobs white-bg d-flex justify-content-between">
                            <div class="jobs_left d-flex align-items-center">
                                <div class="jobs_conetent">
                                    <h4><a href="single.php"><?php echo $scholarship['title']; ?></a></h4>
                                    <div class="links_locat d-flex align-items-center">
                                    </div>
                                </div>
                            </div>
                            <div class="jobs_right">
                                <div class="apply_now">
                                    <a onclick="document.getElementById('modal-wrapper').style.display='block'" class="boxed-btn3">Apply Now</a>
                                </div>
                                <div class="date">
                                    <p>Deadline: <?php echo $scholarship['deadline']; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>

                    
                </div>
            </div>

        </div>
    </div>

            
           
        </div>
    </div>
    <!--/ catagory_area -->
    <!-- popular_catagory_area_start  -->
    <div class="popular_catagory_area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section_title mb-40">
                        <h3>Important Dates</h3>
                    </div>
                </div>
            </div>
            <div class="row">

                <div class="col-lg-4 col-xl-3 col-md-6">
                    <div class="single_catagory">
                        <a><h4>Fall Term Starts: August 6, 2020 </h4></a>

                    </div>
                </div>
                <div class="col-lg-4 col-xl-3 col-md-6">
                    <div class="single_catagory">
                        <a><h4>Fall Term Ends: December 21, 2020</h4></a>

                    </div>
                </div>
                <div class="col-lg-4 col-xl-3 col-md-6">
                    <div class="single_catagory">
                        <a><h4>Winter Term Starts: January 6, 2021</h4></a>

                    </div>
                </div>
                <div class="col-lg-4 col-xl-3 col-md-6">
                    <div class="single_catagory">
                        <a><h4>Winter Term Ends: April 18, 2021 </h4></a>

                    </div>
                </div>
                <div class="col-lg-4 col-xl-3 col-md-6">
                    <div class="single_catagory">
                        <a><h4>Application Deadline: March 31, 2020</h4></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- popular_catagory_area_end  -->
    <!-- job_listing_area_start  -->
    
    <div class="job_listing_area">

        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="section_title">
                        <a id="schlist"><h3>Scholarship Listings</h3></a>
                    </div>
                </div>
                
            </div>
            <div class="job_lists">
                <div class="row">

                <?php foreach ($scholarships1 as $scholarship): ?>
                    <div class="col-lg-12 col-md-12">
                        <div class="single_jobs white-bg d-flex justify-content-between">
                            <div class="jobs_left d-flex align-items-center">
                                <div class="jobs_conetent">
                                    <h4><a href="single.php"><?php echo $scholarship['title']; ?></a></h4>
                                    <div class="links_locat d-flex align-items-center">
                                    </div>
                                </div>
                            </div>
                            <div class="jobs_right">
                                <div class="apply_now">
                                    <a onclick="document.getElementById('modal-wrapper').style.display='block'" class="boxed-btn3">Apply Now</a>
                                </div>
                                <div class="date">
                                    <p>Deadline: <?php echo $scholarship['deadline']; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>

                    
                </div>
            </div>

        </div>
    </div>
    <!-- job_listing_area_end  -->
    <!-- featured_candidates_area_start  -->
    <div class="featured_candidates_area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section_title text-center mb-40">
                        <h3>Instructions</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="candidate_active owl-carousel owl-loaded owl-drag">






                        <div class="owl-stage-outer">
                            <div class="owl-stage" style="transform: translate3d(-960px, 0px, 0px); transition: all 0.8s ease 0s; width: 2640px;">
                                <div class="owl-item cloned" style="width: 210px; margin-right: 30px;">
                                    <div class="single_candidates text-center">

                                        <a href="#"><h4>Supporting Documents</h4></a>

                                    </div>
                                </div><div class="owl-item cloned" style="width: 210px; margin-right: 30px;">
                                    <div class="single_candidates text-center">

                                        <a href="#"><h4>Post-application Process</h4></a>

                                    </div>
                                </div><div class="owl-item cloned" style="width: 210px; margin-right: 30px;">
                                    <div class="single_candidates text-center">

                                        <a href="#"><h4>Maintainibility Criteria</h4></a>

                                    </div>
                                </div><div class="owl-item" style="width: 210px; margin-right: 30px;">
                                    <div class="single_candidates text-center">

                                        <p></p><h4>How To Apply</h4><p></p>

                                    </div>
                                </div><div class="owl-item active" style="width: 210px; margin-right: 30px;">
                                    <div class="single_candidates text-center">

                                        <a href="#"><h4>Eligibility Criteria</h4></a>

                                    </div>
                                </div><div class="owl-item active" style="width: 210px; margin-right: 30px;">
                                    <div class="single_candidates text-center">

                                        <a href="#"><h4>Supporting Documents</h4></a>

                                    </div>
                                </div><div class="owl-item active" style="width: 210px; margin-right: 30px;">
                                    <div class="single_candidates text-center">

                                        <a href="#"><h4>Post-application Process</h4></a>

                                    </div>
                                </div><div class="owl-item" style="width: 210px; margin-right: 30px;">
                                    <div class="single_candidates text-center">

                                        <a href="#"><h4>Maintainibility Criteria</h4></a>

                                    </div>
                                </div><div class="owl-item cloned" style="width: 210px; margin-right: 30px;">
                                    <div class="single_candidates text-center">

                                        <p></p><h4>How To Apply</h4><p></p>

                                    </div>
                                </div><div class="owl-item cloned" style="width: 210px; margin-right: 30px;">
                                    <div class="single_candidates text-center">

                                        <a href="#"><h4>Eligibility Criteria</h4></a>

                                    </div>
                                </div><div class="owl-item cloned" style="width: 210px; margin-right: 30px;">
                                    <div class="single_candidates text-center">

                                        <a href="#"><h4>Supporting Documents</h4></a>

                                    </div>
                                </div>
                            </div>
                        </div><div class="owl-nav disabled"><div class="owl-prev"><i class="ti-angle-left"></i></div><div class="owl-next"><i class="ti-angle-right"></i></div></div><div class="owl-dots disabled"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- featured_candidates_area_end  -->
    <!-- job_searcing_wrap  -->
    <div class="job_searcing_wrap overlay">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 offset-lg-1 col-md-6">
                    <div class="searching_text">
                        <h3>Looking for a Scholarship?</h3>
                        <p>We provide variety of Scholarships no matter who and where you from. </p>
                        <a href="#schlist" class="boxed-btn3">Browse Scholarship</a>

                    </div>
                </div>
                <div class="col-lg-5 offset-lg-1 col-md-6">
                    <div class="searching_text">
                        <h3>Look at our scholarship statistics</h3>
                        
                        <a href="adminstatistics.html" class="boxed-btn3">View Statistics</a>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- job_searcing_wrap end  -->
    <!-- footer start -->

    <footer class="footer">
        <div class="footer_top">
            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-md-6 col-lg-3">
                        <div class="footer_widget wow fadeInUp" data-wow-duration="1s" data-wow-delay=".3s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.3s; animation-name: fadeInUp;">
                            <div class="footer_logo">
                                <a href="#">
                                    <img src="assets/images/1.png" alt="">
                                </a>
                            </div>
                            <p>
                                studentscholarships@support.com<br>
                                +403 220 5333 <br>
                                2500 University Dr NW, Calgary, AB T2N 1N4
                            </p>
                            <div class="socail_links">
                                <ul>
                                    <li>
                                        <a href="#">
                                            <i class="ti-facebook"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="fa fa-google-plus"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="fa fa-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            <i class="fa fa-instagram"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>

                        </div>
                    </div>
                    <div class="col-xl-2 col-md-6 col-lg-2">
                        <div class="footer_widget wow fadeInUp" data-wow-duration="1.1s" data-wow-delay=".4s" style="visibility: visible; animation-duration: 1.1s; animation-delay: 0.4s; animation-name: fadeInUp;">
                            <h3 class="footer_title">
                                Quick links
                            </h3>
                            <ul>
                                <li><a href="#">Home Page</a></li>
                                <li><a href="<?php echo BASE_URL . '/index.php' ?>"> Available Scholarships</a></li>
                                <li><a href="#">Scholarship Eligibility</a></li>

                            </ul>

                        </div>
                    </div>
                    <div class="col-xl-3 col-md-6 col-lg-3">
                        <div class="footer_widget wow fadeInUp" data-wow-duration="1.2s" data-wow-delay=".5s" style="visibility: visible; animation-duration: 1.2s; animation-delay: 0.5s; animation-name: fadeInUp;">
                            <h3 class="footer_title">
                                Search Scholarships By Faculty
                            </h3>
                            <ul>
                                <li><a href="#">Arts</a></li>
                                <li><a href="#">Business &amp; Law</a></li>
                                <li><a href="#">Education</a></li>
                                <li><a href="#">Engineering</a></li>
                                <li><a href="#">Science</a></li>
                                <li><a href="#">Nursing</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6 col-lg-4">
                        <div class="footer_widget wow fadeInUp" data-wow-duration="1.3s" data-wow-delay=".6s" style="visibility: visible; animation-duration: 1.3s; animation-delay: 0.6s; animation-name: fadeInUp;">
                            <h3 class="footer_title">
                                Know when a Scholarship is Available, Subscribe:
                            </h3>
                            <form action="#" class="newsletter_form">
                                <input type="text" placeholder="Enter your university email">
                                <button type="submit">Subscribe</button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copy-right_text wow fadeInUp" data-wow-duration="1.4s" data-wow-delay=".3s" style="visibility: visible; animation-duration: 1.4s; animation-delay: 0.3s; animation-name: fadeInUp;">
            <div class="container">
                <div class="footer_border"></div>
                <div class="row">
                    <div class="col-xl-12">
                        <p class="copy_right text-center">
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            Copyright ©
                            <script>document.write(new Date().getFullYear());</script>2020 All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--/ footer end  -->
    <!-- link that opens popup -->
    <!-- JS here -->
    <script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/ajax-form.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/scrollIt.js"></script>
    <script src="assets/js/jquery.scrollUp.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/nice-select.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/gijgo.min.js"></script>



    <!--contact js-->
    <script src="assets/js/contact.js"></script>
    <script src="assets/js/jquery.ajaxchimp.min.js"></script>
    <script src="assets/js/jquery.form.js"></script>
    <script src="assets/js/jquery.validate.min.js"></script>
    <script src="assets/js/mail-script.js"></script>


    <script src="assets/js/main.js"></script>



</body>

</html>
